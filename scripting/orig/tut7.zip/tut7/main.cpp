#include "vm.h"

int main ()  {
   VMachine vm;

   vm.Read();
   vm.Execute();
   return 0;
}